#!/bin/bash
# AutoFlowNG Landing Page - Install Script
# Run from: /workspaces/autoflowng-frontend/frontend

FRONTEND=/workspaces/autoflowng-frontend/frontend
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "Installing landing page files..."

# 1. Replace Landing.tsx
cp "$SCRIPT_DIR/src/pages/Landing.tsx" "$FRONTEND/src/pages/Landing.tsx"
echo "✓ Landing.tsx replaced"

# 2. Create components/landing folder if it doesn't exist
mkdir -p "$FRONTEND/src/components/landing"

# 3. Copy all landing components
cp "$SCRIPT_DIR/src/components/landing/"*.tsx "$FRONTEND/src/components/landing/"
echo "✓ 12 landing components copied"

# 4. Copy public images from the landing folder
cp -r /workspaces/autoflowng-frontend/landing/public/. "$FRONTEND/public/"
echo "✓ Public images copied"

echo ""
echo "Done! Landing page installed successfully."
echo "Sections: Navigation, Hero, Features, HowItWorks, Infrastructure,"
echo "          Metrics, Integrations, Security, Developers, Pricing, CTA, Footer"
echo "Testimonials: REMOVED (replaced by your real user testimonial system)"
echo "Trial period: 3-day (updated throughout)"
